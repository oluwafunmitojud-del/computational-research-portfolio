# Computational Research Portfolio

**Three reproducible Python studies in inverse problems, stochastic systems, and constrained optimization**

Prepared for **Dorcas Oluwafunmitoju** as a portfolio demonstration. These are **new synthetic, educational computational studies**, not publications, institutional research appointments, employer-funded projects, or third-party certifications. The program code, tests and experimental outputs in this package were generated with AI assistance; the candidate should read, run, understand and confirm the work before claiming authorship or independent implementation.

## Studies and verified numerical results

| Study | Evidence from fresh local runs | Reproduce |
|---|---|---|
| 1. Inverse diffusion / adjoint sensitivity | 120 seeded synthetic inverse problems; median relative conductivity error **0.1158 with ridge** versus **0.1333 without**; 85% of scenarios favored ridge | `results/inverse_diffusion_trials.csv` |
| 2. Transient stochastic queue reliability | 120 configurations; max uniformization/expm disagreement **2.36e-13**; median absolute risk error of simple mean-rate approximation **0.0730**; 10/10 fixed Monte Carlo checks contained analytic risk in their Wilson 95% intervals | `results/transient_queue_trials.csv` |
| 3. Correlated-fault regression-test optimization | 300 seeded 10-test portfolios; **98.685%** mean of exact optimum for latent-aware greedy vs **97.104%** for marginal-independence greedy; 95 better, 13 worse, 192 ties | `results/correlated_test_selection_trials.csv` |

All cases use synthetic data. Numbers are conditional on the documented simulation design; they are **not** claims of production performance or generally superior algorithms. They deliberately **replace**, rather than retroactively validate, the different illustrative figures in the supplied fictional CV template.

## Quick start

Tested with Python 3.11, NumPy, SciPy and matplotlib. No API keys, external datasets or internet access required after dependency installation.

```bash
python -m venv .venv
source .venv/bin/activate              # Windows: .venv\\Scripts\\activate
python -m pip install -e '.[test]'
pytest -q
python scripts/run_experiments.py
```

The test suite contains **55 parametrized test cases** covering adjoint gradients, positive-definite sparse matrices, independently computed CTMC transient distributions, Monte Carlo cross-checks, exact subset oracles, and decision constraints. The `scripts/run_experiments.py` command regenerates each results CSV, the machine-readable summary and the figures from fixed seeds. On a different numerical stack, results may vary slightly.

## Browse the work

- Research overview: [`docs/index.html`](docs/index.html) (can be published with GitHub Pages)
- Full combined research report: [`docs/reports/Research_Portfolio_Report.pdf`](docs/reports/Research_Portfolio_Report.pdf)
- Study 1 methodology: [`STUDY_01_INVERSE_DIFFUSION.md`](STUDY_01_INVERSE_DIFFUSION.md)
- Study 2 methodology: [`STUDY_02_TRANSIENT_QUEUES.md`](STUDY_02_TRANSIENT_QUEUES.md)
- Study 3 methodology: [`STUDY_03_CORRELATED_TESTS.md`](STUDY_03_CORRELATED_TESTS.md)
- Source code: [`src/dorcas_research/`](src/dorcas_research/)
- Tests: [`tests/`](tests/)
- Results: [`results/`](results/)
- Google Sites content + publishing: [`GOOGLE_SITES_COPY.md`](GOOGLE_SITES_COPY.md), [`PUBLISHING_GUIDE.md`](PUBLISHING_GUIDE.md)

## Research ethics and limitations

**Provenance:** The included source and experiments were created specifically as independent, AI-assisted portfolio demonstration materials. Outputs are reproducible and tests pass locally, but independent peer review has not been performed. Actual employment, academic credentials, authorship and historical research experience must be substantiated separately. Synthetic experimental outcomes should not be described as employer outcomes, published papers or undergraduate thesis results.

**Portability:** Sparse solvers, floating-point routines and stochastic simulations can vary slightly with environment. Reported point estimates represent these specific fixed seeds and test setups. See the individual notes for mathematical assumptions and failure modes.

**Publish:** Copy to a repository under **your own GitHub account**, then publish the `docs/` folder as GitHub Pages. This package intentionally contains no made-up GitHub or Google Sites URLs. See `PUBLISHING_GUIDE.md`.

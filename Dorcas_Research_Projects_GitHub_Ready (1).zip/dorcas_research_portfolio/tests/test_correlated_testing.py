import numpy as np
import pytest
from itertools import combinations
from dorcas_research.correlated_testing import TestPortfolio,generate_portfolio,sample_trial

def simple():
    return TestPortfolio(np.array([.5,.5]),np.array([3.,1.]),
      np.array([[[.8,.2],[.2,.7]],[[.4,.6],[.1,.2]],[[.5,.1],[.9,.05]]]),
      np.array([1.,2.,1.]),np.array([.1,.1,.2]),2.5,.25)

def test_manual_expectation():
    p=simple()
    answer=3*(.5*.8+.5*.2)+(.5*.2+.5*.7)
    assert np.isclose(p.value([0]),answer)

def test_exact_oracle_matches_manual_brute_force():
    p=simple()
    options=[]
    for n in range(p.n+1):
        options.extend(combinations(range(p.n),n))
    brute=max(p.value(s) for s in options if p.feasible(s))
    assert np.isclose(p.oracle()['value'],brute)

@pytest.mark.parametrize('seed',list(range(10)))
def test_greedy_is_feasible_and_bounded_by_exact_oracle(seed):
    p=generate_portfolio(np.random.default_rng(seed),n=9)
    optimal=p.oracle()
    for independence in [True,False]:
        candidate=p.greedy(assume_independent=independence)
        assert p.feasible(candidate['subset'])
        assert candidate['value'] <= optimal['value']+1e-10
        assert candidate['value']>=0

def test_latent_regimes_induce_dependence():
    p=TestPortfolio([.5,.5],[1.],
       np.array([[[.95],[.05]],[[.95],[.05]]]),[1,1],[.1,.1],2,1)
    # High-detection state affects both tests, so true union < independent proxy.
    assert p.value([0,1])<p.value([0,1],assume_independent=True)

def test_monotonicity_and_diminishing_returns():
    p=generate_portfolio(np.random.default_rng(8),n=7)
    for i in range(3):
        a=p.value([i])
        b=p.value([i,4])
        c=p.value([i,4,5])
        assert a<=b+1e-12<=c+1e-12
        assert p.value([4])-p.value([])>=b-a-1e-12

def test_never_exceeds_total_severity():
    p=generate_portfolio(np.random.default_rng(88),n=8)
    assert p.value(range(p.n))<=p.severity.sum()+1e-10

def test_invalid_probability_rejected():
    with pytest.raises(ValueError):
        TestPortfolio([1],[1],np.array([[[1.1]]]),[1],[.1],2,.2)

def test_repeatability():
    a=sample_trial(generate_portfolio(np.random.default_rng(23)))
    b=sample_trial(generate_portfolio(np.random.default_rng(23)))
    assert a==b

def test_empty_portfolio_value():
    assert simple().value([])==0

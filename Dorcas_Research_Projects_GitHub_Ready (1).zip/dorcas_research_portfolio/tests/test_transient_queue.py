import numpy as np
import pytest
from dorcas_research.transient_queue import (generator,uniformize,propagate,block_risk,
  stationary_mean_rate_approx,simulate_risk,choose_capacity)

@pytest.mark.parametrize("servers,buffer",[(1,0),(2,1),(3,2),(5,1)])
def test_generator_conserves_probability(servers,buffer):
    Q=generator(3.5,1.4,servers,servers+buffer)
    assert np.allclose(Q.sum(axis=1),0,atol=1e-13)
    assert np.all(Q-np.diag(np.diag(Q)) >=-1e-12)
    assert not np.any(Q[-1])

@pytest.mark.parametrize("lambda_,mu,T",[(0,1,2),(.1,1,3),(1.,1.,1.),(4.,2.,1.7),(7.,.7,2.5),(12.,1.,5)])
def test_uniformization_agrees_with_independent_expm(lambda_,mu,T):
    schedule=[(T,lambda_)]
    p1=propagate(schedule,mu,2,4)
    p2=propagate(schedule,mu,2,4,mode="expm")
    assert np.allclose(p1,p2,atol=2e-12,rtol=1e-11)
    assert abs(p1.sum()-1)<5e-12

@pytest.mark.parametrize("mode",["uniformization","expm"])
def test_piecewise_burst_honors_conservation(mode):
    sched=[(1,.5),(.5,9),(1,1.5)]
    p=propagate(sched,2.,3,5,mode=mode)
    assert abs(p.sum()-1)<1e-11
    assert np.min(p)>-1e-12

def test_zero_duration_and_zero_arrivals():
    p=propagate([(0,10),(4,0)],2.,2,3)
    assert np.allclose(p,np.eye(5)[0])

def test_risk_increases_with_arrival_load():
    a=block_risk([(2,1.)],2.,2,1)
    b=block_risk([(2,6.)],2.,2,1)
    assert 0<=a<b<1

def test_simulation_95_percent_interval_contains_analytic_risk():
    schedule=[(.8,.8),(.7,5.),(.8,1.)]
    actual=block_risk(schedule,1.8,2,buffer=1)
    mc=simulate_risk(schedule,1.8,2,buffer=1,replications=25000,seed=99)
    assert mc['lo95']<=actual<=mc['hi95']

def test_capacity_choice_obeys_risk_constraint():
    sched=[(1,3.),(1,7.),(1,2.)]
    x=choose_capacity(sched,2.,max_servers=9,buffer=1,risk_limit=.08)
    assert x['feasible']
    assert x['risk']<=.08
    if x['servers']>1:
        assert block_risk(sched,2.,x['servers']-1,1)>.08

def test_invalid_generator_raises():
    with pytest.raises(ValueError): generator(-1.,2.,2,3)
    with pytest.raises(ValueError): generator(1.,2.,3,2)

def test_stationary_baseline_output_is_probability():
    sched=[(.5,0.),(.5,11.),(1,0.)]
    p=stationary_mean_rate_approx(sched,2.,3,1)
    assert 0<=p<=1

import numpy as np
import pytest
from scipy.sparse.linalg import eigsh
from dorcas_research.inverse_diffusion import DiffusionModel,scenario

@pytest.mark.parametrize("n",[3,5,8,11])
def test_matrix_is_symmetric_positive_definite(n):
    m=DiffusionModel(n)
    A=m.assemble([-.4,.2,.1,.3]).toarray()
    assert np.allclose(A,A.T)
    assert np.linalg.eigvalsh(A).min()>0

@pytest.mark.parametrize("seed",list(range(8)))
def test_discrete_adjoint_matches_independent_centered_difference(seed):
    rng=np.random.default_rng(seed)
    m=DiffusionModel(5)
    theta=rng.normal(0,.2,4)
    sensors=rng.choice(25,size=12,replace=False)
    obs=m.observe(np.zeros(4),sensors)+rng.normal(0,.003,12)
    _,adj=m.objective_and_gradient(theta,sensors,obs,.01,.4)
    finite=[]
    for k in range(4):
        d=np.eye(4)[k]*1e-5
        j1=m.objective_and_gradient(theta+d,sensors,obs,.01,.4)[0]
        j0=m.objective_and_gradient(theta-d,sensors,obs,.01,.4)[0]
        finite.append((j1-j0)/2e-5)
    assert np.allclose(adj,finite,atol=1e-7,rtol=1e-5)

@pytest.mark.parametrize("n",[5,8])
def test_discretized_operator_recovers_exact_state(n):
    m=DiffusionModel(n)
    t=[.15,-.25,.3,-.1]
    u=m.state(t)
    assert np.linalg.norm(m.assemble(t)@u-m.f)<1e-10

def test_zero_parameter_yields_unit_conductivity():
    m=DiffusionModel(7)
    assert np.allclose(np.exp(m.B@np.zeros(4)),1)

def test_fit_clean_data_recovers_forward_measurements():
    m=DiffusionModel(9)
    sensors=np.arange(0,81,2)
    true=np.array([.15,-.12,.2,-.2])
    y=m.observe(true,sensors)
    res=m.fit(sensors,y,sigma=.001,ridge=0)
    assert np.linalg.norm(m.observe(res.x,sensors)-y)<1e-4

def test_regularized_objective_checks_hyperparameters():
    m=DiffusionModel(5)
    with pytest.raises(ValueError):
        m.objective_and_gradient(np.zeros(4),[1],[0],0,.2)
    with pytest.raises(ValueError):
        m.objective_and_gradient(np.zeros(4),[],[],.1,.2)

def test_scenario_reproducible():
    m=DiffusionModel(6)
    a=scenario(m,np.random.default_rng(42),sensor_count=12)
    b=scenario(m,np.random.default_rng(42),sensor_count=12)
    assert a==b

def test_more_sensors_support_more_rank_information():
    m=DiffusionModel(7)
    J=m.observation_jacobian(np.zeros(4),[1,7,12,23,35,40,46])
    assert J.shape==(7,4)
    assert np.all(np.isfinite(J))

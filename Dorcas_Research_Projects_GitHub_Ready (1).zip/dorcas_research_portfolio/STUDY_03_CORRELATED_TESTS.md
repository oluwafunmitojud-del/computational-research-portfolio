# Study 03 — Correlated-Fault Regression-Test Optimization

## Research question

How does explicitly modeling common latent fault conditions change the choice of regression tests when execution time and expected false-alert budgets are binding?

## Mathematical formulation

A scenario includes test set `T`, fault classes `d`, environment regimes `z`, regime weights `w_z`, and conditional test detection probabilities `p_tdz`. Conditional on a shared `z` and fault class `d`, outcomes are assumed independent across tests; **marginal** outcomes therefore can be correlated.

For a selected subset `S`, the detection score is

`F(S) = sum_d severity_d * sum_z w_z * [1 - product_(t in S)(1-p_tdz)]`.

Select `S` to maximize `F(S)` subject to `sum_(t in S) runtime_t <= time_budget` and `sum_(t in S) false_alarm_t <= alarm_budget`. The false-alert cost is expected and additive; the model does **not** infer joint false-alert probability from the latent detection model.

## Methods

**Ground truth oracle:** enumerate **all 2^10 subsets** for each 10-test case, reject infeasible subsets, and find the highest true-model score. Exactness applies to these small synthetic instances only.

**Correlation-aware greedy:** iteratively choose a feasible test with the largest marginal true-model objective gain divided by the average normalized consumption of two budgets. Also evaluate the best feasible singleton to reduce ratio-greedy's oversized-item pathology.

**Marginal-independence baseline:** replace the conditional model with `p_bar(t,d)=sum_z w_z p_tdz`, then greedily optimize the product of independent marginal failures under identical budgets. Evaluate its selected subset using the **true** latent-regime model for a fair comparison.

## Experiment

300 reproducible 10-test synthetic portfolios, with three shared environments, five fault classes and specialist tests capable of detecting some faults in an otherwise adverse regime. Individual runtimes, false-alert budgets and fault severities are drawn from documented seeded distributions in the generator code. Seed `20261022`.

## Measured results

| Measurement | Correlation-aware greedy | Marginal-independence greedy |
|---|---:|---:|
| Mean value as a fraction of exact optimum | **98.685%** | **97.104%** |
| Worst fraction in this sample | **87.011%** | **82.067%** |

The correlation-aware policy outperformed its counterpart in **95** portfolios, underperformed in **13**, and **tied in 192**. A small average advantage does not mean the correlation-aware heuristic wins in every instance. All reported scores are computed under the true latent-model objective, not under the approximation preferred by the baseline.

Records: `results/correlated_test_selection_trials.csv`; plot: `figures/correlated_testing_comparison.png`.

## Interpretation and limitations

The latent-regime conditional-independence assumption is synthetic and untested on production failures. Enumerating 2^10 subsets is feasible; scaling exact enumeration to thousands of tests is not. This heuristic is not claimed to have an optimality guarantee for the two-budget problem, although the test objective is monotone with diminishing returns under its stated assumptions. The 300 seeded outcomes are reproducible samples, not a proof of universal superiority or a published benchmark.

## Reproduce

`PYTHONPATH=src python scripts/run_experiments.py` and `PYTHONPATH=src pytest -q tests/test_correlated_testing.py`.

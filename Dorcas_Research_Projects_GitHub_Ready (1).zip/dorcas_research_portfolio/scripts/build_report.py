"""Generate a paginated report from validated measured outcomes, no hardcoded invented metrics."""
from pathlib import Path
import json
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.lib.units import cm
from reportlab.platypus import (SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,
                               Image,PageBreak,KeepTogether,HRFlowable)
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfbase import pdfmetrics

ROOT=Path(__file__).resolve().parents[1]
output=ROOT/'docs'/'reports'/'Research_Portfolio_Report.pdf'
output.parent.mkdir(parents=True,exist_ok=True)
data=json.load(open(ROOT/'results'/'summary.json'))

NAVY=colors.HexColor('#122337');TEAL=colors.HexColor('#0B8177')
BG=colors.HexColor('#EEF4F4');DARK=colors.HexColor('#273647');MUTED=colors.HexColor('#5C6D78')
PATH='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
PATHB='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
if Path(PATH).exists():
 pdfmetrics.registerFont(TTFont('DejaVu',PATH))
 pdfmetrics.registerFont(TTFont('DejaVu-Bold',PATHB))
 font='DejaVu';bold='DejaVu-Bold'
else:
 font='Helvetica';bold='Helvetica-Bold'
styles={
 'cover':ParagraphStyle('cover',fontName=bold,fontSize=25,leading=35,textColor=NAVY,spaceAfter=10),
 'subtitle':ParagraphStyle('sub',fontName=font,fontSize=11,leading=18,textColor=MUTED,spaceAfter=16),
 'h1':ParagraphStyle('h1',fontName=bold,fontSize=16,leading=23,textColor=NAVY,spaceAfter=10),
 'h2':ParagraphStyle('h2',fontName=bold,fontSize=10.5,leading=17,textColor=TEAL,spaceBefore=12,spaceAfter=5),
 'body':ParagraphStyle('body',fontName=font,fontSize=9,leading=15,textColor=DARK,spaceAfter=9),
 'small':ParagraphStyle('small',fontName=font,fontSize=7.8,leading=12,textColor=MUTED,spaceAfter=7),
 'bullet':ParagraphStyle('bullet',fontName=font,fontSize=8.5,leading=14,textColor=DARK,spaceAfter=5,leftIndent=14,bulletIndent=4),
 'cell':ParagraphStyle('cell',fontName=font,fontSize=8.7,leading=14,textColor=DARK),
 'key':ParagraphStyle('key',fontName=bold,fontSize=10,leading=16,textColor=NAVY),
}
S=styles

def P(text,style='body'):
 return Paragraph(text, S[style])

def bullet(text):
 return Paragraph('&#8226; '+text,S['bullet'])

def table(rows, colWidths=None):
 rows=[[P(str(v),'cell') for v in row] for row in rows]
 x=Table(rows, colWidths=colWidths, hAlign='LEFT',repeatRows=1)
 x.setStyle(TableStyle([
 ('BACKGROUND',(0,0),(-1,0),BG),('TEXTCOLOR',(0,0),(-1,0),NAVY),
 ('LINEBELOW',(0,0),(-1,0),.8,TEAL),('LINEBELOW',(0,1),(-1,-1),.3,colors.HexColor('#D8E3E6')),
 ('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),9),
 ('RIGHTPADDING',(0,0),(-1,-1),8),('TOPPADDING',(0,0),(-1,-1),8),
 ('BOTTOMPADDING',(0,0),(-1,-1),8),
 ]))
 return x

def chart(name, width=16.4, maxheight=10.0):
 from PIL import Image as PILImage
 file=ROOT/'figures'/name
 w,h=PILImage.open(file).size
 ratio=min((width*cm)/w,(maxheight*cm)/h)
 return Image(str(file),width=w*ratio,height=h*ratio)

def cover(canvas,doc):
 canvas.saveState()
 w,h=A4
 canvas.setFillColor(NAVY); canvas.rect(0,h-1.5*cm,w,1.5*cm,fill=1,stroke=0)
 canvas.setFillColor(TEAL);canvas.rect(0,h-1.65*cm,w,.15*cm,fill=1,stroke=0)
 canvas.setFont(bold,8);canvas.setFillColor(colors.white)
 canvas.drawString(1.8*cm,h-.99*cm,'DORCAS OLUWAFUNMITOJU  /  COMPUTATIONAL RESEARCH')
 footer(canvas,doc)
 canvas.restoreState()

def later(canvas,doc):
 canvas.saveState()
 w,h=A4
 canvas.setFillColor(NAVY);canvas.rect(0,h-1.25*cm,w,1.25*cm,fill=1,stroke=0)
 canvas.setFillColor(colors.white);canvas.setFont(bold,8)
 canvas.drawString(1.8*cm,h-.78*cm,'COMPUTATIONAL RESEARCH PORTFOLIO  /  SYNTHETIC STUDIES')
 footer(canvas,doc)
 canvas.restoreState()

def footer(c,doc):
 w,h=A4
 c.setStrokeColor(colors.HexColor('#D9E3E6'));c.line(1.8*cm,1.28*cm,w-1.8*cm,1.28*cm)
 c.setFont(font,6.7);c.setFillColor(MUTED)
 c.drawString(1.8*cm,.94*cm,'Independent AI-assisted educational demonstrations | 20 Oct 2026')
 c.drawRightString(w-1.8*cm,.94*cm,str(doc.page))

story=[]
def add(*things):story.extend(things)
inv=data['inverse_diffusion'];queue=data['transient_queue'];test=data['correlated_testing']

# Cover
add(Spacer(1,.8*cm),P('Evidence-led computational<br/>research portfolio','cover'),
 P('Inverse problems &nbsp; / &nbsp; Stochastic processes &nbsp; / &nbsp; Constrained optimization','subtitle'),
 HRFlowable(width='100%',thickness=1.5,color=TEAL,spaceAfter=18),
 P('Prepared for <b>Dorcas Oluwafunmitoju</b>','h1'),
 P('Three functioning scientific-Python studies with independent numerical checks, raw reproducible synthetic datasets, figures and 55 passing local automated tests. This is a newly constructed portfolio demonstration and not a record of previous research employment or peer-reviewed publications.','body'),
 Spacer(1,.5*cm),
 table([['STUDY','VALIDATED FINDING'],
 ['01  |  Inverse diffusion','120 inversions; median relative field error 0.1158 (ridge) vs 0.1333 (unregularized).'],
 ['02  |  Transient queues','120 scenarios; uniformization and independent matrix exponential agree to within 2.4 x 10^-13.'],
 ['03  |  Correlated testing','300 portfolios; latent-aware greedy mean 98.69% of exact optimum vs 97.10% for marginal greedy.']],
 [5.1*cm,11.8*cm]),
 Spacer(1,.65*cm),P('Research integrity and scope','h2'),
 P('The investigations use synthetic data, fixed random seeds and explicit mathematical assumptions. All numbers arise from executable code included in the accompanying ZIP, not from the earlier fictional CV example. The authoring process used AI assistance, and personal authorship, employment history and academic credentials require separate verification.','body'),
 P('Reproduction: install the package with <b>pip install -e ".[test]"</b>, run <b>pytest -q</b>, then <b>python scripts/run_experiments.py</b>. Full methods and per-case CSVs accompany this report.','small'),
 PageBreak())

# Inverse
add(P('01  /  Inverse diffusion and adjoint sensitivity','h1'),
 P('<b>Research question.</b> How do sparse observation placement and ridge regularization affect reconstruction of spatial conductivity from an elliptic forward model?','body'),
 P('Mathematical method','h2'),
 P('Discretize a unit-square elliptic diffusion equation with zero Dirichlet boundary conditions on a 10 x 10 interior grid. The positive conductivity field is exp(B theta), with four smooth spatial bases. Symmetric harmonic-mean edge conductances form a sparse, positive-definite operator. Recover theta from noisy synthetic sensor observations using box-constrained L-BFGS-B, comparing a ridge penalty of 0.07 with no penalty.','body'),
 P('To avoid differentiating the full sparse linear solve, a discrete adjoint solves A-transpose times p equal to the residual sensitivity and evaluates minus p-transpose times the matrix derivative times u. Eight randomized centered-difference comparisons check the derived gradient.','body'),
 P('Measured experiments','h2'),
 table([['SENSOR COUNT','RIDGE MEDIAN ERROR','UNREGULARIZED MEDIAN'],
        ['8','0.20347','0.29786'],['16','0.11581','0.13657'],['28','0.07964','0.09373']],
       [4.0*cm,6.4*cm,6.5*cm]),
 Spacer(1,.22*cm),
 P('All 120 held-out synthetic cases: ridge median relative conductivity error <b>0.11581</b>, unregularized median <b>0.13328</b>; ridge won in <b>85%</b> of cases. Both methods use the same sensor data, bounded optimization and error definition.','body'),
 chart('inverse_diffusion_comparison.png',width=16.8,maxheight=6.3),
 Spacer(1,.25*cm),P('Interpretation','h2'),
 P('More sensors improved recovery in this selected parameterization. The experiment does not imply that regularization universally wins. Identifiability, source fields, real-world boundary conditions and the choice of penalty can materially change these findings.','small'),
 PageBreak())

# Queue
add(P('02  /  Transient stochastic queue reliability','h1'),
 P('<b>Research question.</b> When do average-rate stationary shortcuts distort the probability of at least one blocked arrival during a short burst?','body'),
 P('Mathematical method','h2'),
 P('A piecewise-constant arrival-rate M(t)/M/c/K queue starts empty. Occupancy states 0 to K are augmented with an absorbing state reached upon the first blocked arrival. Primary CTMC propagation uses Poisson uniformization with a tail-controlled series; an independent dense matrix exponential provides an oracle. A separate event-driven Monte Carlo engine uses exponential competition between arrivals and departures.','body'),
 P('The comparison baseline uses the mean arrival rate, the corresponding stationary capacity distribution, and a simple thinning approximation to short-horizon loss. This is a transparent heuristic, <b>not</b> an exact queueing baseline.','body'),
 P('Measured experiments','h2'),
 table([['MEASURE','VALUE'],
       ['Seeded synthetic configurations','120'],
       ['Maximum uniformization vs exponential difference','2.36 x 10^-13'],
       ['Maximum probability-conservation residual','2.83 x 10^-13'],
       ['Median absolute shortcut risk error','0.07301 probability units'],
       ['Cases with shortcut error above 0.05','60.83%'],
       ['Stochastic comparisons','10 of 10 analytic risks inside fixed Wilson 95% intervals']],
       [10*cm,6.9*cm]),
 Spacer(1,.38*cm),chart('transient_queue_comparison.png',width=16.7,maxheight=5.0),
 Spacer(1,.28*cm),P('Interpretation and limitation','h2'),
 P('Arrival rates are Poisson within each segment; service durations are exponential and capacity is finite. The result estimates first-loss probability only, not the number of lost customers or a service-level agreement for real workloads. Monte Carlo intervals check a small fixed subset; they do not establish general calibration.','small'),
 PageBreak())

# Correlated
add(P('03  /  Correlated-fault regression-test optimization','h1'),
 P('<b>Research question.</b> How does shared latent fault environment change regression-test selection with time and expected false-alert limits?','body'),
 P('Model and optimization','h2'),
 P('For fault d and latent regime z, detection events are conditionally independent across tests with probabilities p(t,d,z). The true detection score sums, over fault severity and regime probabilities, the probability that at least one selected test detects the fault. Unconditionally, tests are correlated because they share z. Two additive limits constrain total runtime and expected false alerts.','body'),
 P('Compare an explicit latent-model greedy method with one based on independent marginal detection probabilities. Both use a normalized two-budget gain-to-cost heuristic and are evaluated by the same true objective. Exhaustive search of all 1,024 subsets gives an exact reference optimum for every 10-test portfolio.','body'),
 P('Measured experiments','h2'),
 table([['MEASURE','LATENT-AWARE','MARGINAL BASELINE'],
       ['Mean quality as fraction of exact optimum','98.685%','97.104%'],
       ['Worst case in sample','87.011%','82.067%']],
       [7.0*cm,4.9*cm,5.0*cm]),
 Spacer(1,.25*cm),P('Among 300 seeded synthetic portfolios: <b>95 aware wins</b>, <b>13 marginal wins</b>, and <b>192 ties</b>. The latent-aware heuristic is not guaranteed globally optimal under both budgets.','body'),
 chart('correlated_testing_comparison.png',width=16.6,maxheight=8.3),
 P('Interpretation and limitation','h2'),
 P('This is a synthetic latent-regime study with ten tests per instance and five fault classes. It should not be described as a demonstrated production deployment, a published benchmark, or a general approximation theorem for the two-budget case.','small'),
 PageBreak())

# Transparency
add(P('Research verification and publication notes','h1'),
 P('What was actually checked','h2'),
 bullet('55 local parametrized tests passed, including discrete-adjoint gradient checks, numerical matrix properties, independent transient-state cross-checks, direct simulation and exact-search comparisons.'),
 bullet('120 inverse cases, 120 queue cases and 300 selection cases have stored per-case CSV records.'),
 bullet('Project scripts regenerate the data and figures deterministically using fixed seeds; source, requirements and commands are included in the ZIP.'),
 bullet('The measured numbers in these pages do <b>not</b> reproduce the illustrative original CV figures; they supersede them for these new synthetic studies.'),
 P('Where to find the files','h2'),
 table([['MATERIAL','RELATIVE PATH'],
       ['Python reference implementations','src/dorcas_research/*.py'],
       ['Automated verification','tests/test_*.py'],
       ['Experiment driver','scripts/run_experiments.py'],
       ['Machine-readable numerical summary','results/summary.json'],
       ['Complete per-case records','results/*.csv'],
       ['Reproducibility and methods','STUDY_0*.md and README.md'],
       ['Portfolio site ready for hosting','docs/index.html']],
       [7*cm,9.9*cm]),
 Spacer(1,.45*cm),P('Reproducible commands','h2'),
 P('<b>python -m pip install -e ".[test]"</b><br/><b>pytest -q</b><br/><b>python scripts/run_experiments.py</b>','body'),
 P('Responsible disclosure','h2'),
 P('Created with AI assistance as an independent learning and demonstration package for the named candidate. No independent claim of historical authorship, university laboratory employment, funded research, thesis completion or peer-reviewed status is made. Any CV should separately confirm its university, CGPA, dates and employer entries; removing the word "fictional" from a previous template does not independently verify them.','body'),
 P('Select background sources','h2'),
 P('D. Givoli (2021), A tutorial on the adjoint method for inverse problems, doi:10.1016/j.cma.2021.113810. G. Rubino (2021), Transient Analysis of Markovian Queueing Systems, doi:10.1002/9781119755234.ch8. Full sources and limitations appear in REFERENCES.md.','small'))


doc=SimpleDocTemplate(str(output),pagesize=A4,rightMargin=1.8*cm,leftMargin=1.8*cm,
                      topMargin=2.2*cm,bottomMargin=1.8*cm,title='Reproducible Computational Research Portfolio — Dorcas Oluwafunmitoju',
                      author='Computational Research Portfolio (AI-assisted)')
doc.build(story,onFirstPage=cover,onLaterPages=later)
print(output)

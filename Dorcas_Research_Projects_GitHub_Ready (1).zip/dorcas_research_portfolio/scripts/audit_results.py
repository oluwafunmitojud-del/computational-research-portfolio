"""Independently recompute reported aggregates from the stored per-case records."""
from pathlib import Path
import json,csv,math,hashlib
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'results'
s=json.loads((DATA/'summary.json').read_text())

def rows(name):
    with (DATA/name).open() as f:return list(csv.DictReader(f))

def close(a,b,tol=2e-7):
    if not abs(float(a)-float(b))<tol:
        raise AssertionError(f'Expected {a} approx {b}')

inv=rows('inverse_diffusion_trials.csv');qu=rows('transient_queue_trials.csv');co=rows('correlated_test_selection_trials.csv')
assert (len(inv),len(qu),len(co))==(120,120,300)
a=s['inverse_diffusion']
close(np.median([float(x['error_regularized']) for x in inv]),a['median_ridge_error'])
close(np.median([float(x['error_unregularized']) for x in inv]),a['median_unregularized_error'])
close(np.mean([float(x['error_regularized'])<float(x['error_unregularized']) for x in inv]),a['ridge_better_fraction'])
for count,v in a['by_sensor_count'].items():
 r=[x for x in inv if x['sensors']==count]
 close(np.median([float(x['error_regularized']) for x in r]),v['ridge_median'])
 close(np.median([float(x['error_unregularized']) for x in r]),v['unregularized_median'])
q=s['transient_queue']
close(max(float(x['conservation_residual']) for x in qu),q['max_abs_probability_conservation_residual'])
close(max(float(x['oracle_max_deviation']) for x in qu),q['max_abs_uniformization_vs_expm_error'])
close(np.median([float(x['absolute_stationary_error']) for x in qu]),q['median_abs_mean_rate_risk_error'])
checks=json.loads((DATA/'queue_monte_carlo_checks.json').read_text())
assert len(checks)==q['monte_carlo_checks']
assert sum(x['within_95_percent_interval'] for x in checks)==q['mc_95pct_coverage_count']
t=s['correlated_testing']
close(np.mean([float(x['aware_fraction_of_optimum']) for x in co]),t['mean_aware_fraction_of_exact_optimum'])
close(np.mean([float(x['independent_fraction_of_optimum']) for x in co]),t['mean_naive_fraction_of_exact_optimum'])
comparisons=[np.sign(float(x['aware_fraction_of_optimum'])-float(x['independent_fraction_of_optimum'])) for x in co]
assert (sum(c>0 for c in comparisons),sum(c<0 for c in comparisons),sum(c==0 for c in comparisons))==(t['aware_wins'],t['naive_wins'],t['ties'])
assert all(float(x['correlation_aware'])<=float(x['optimum'])+1e-7 for x in co)
assert all(float(x['independence_assuming'])<=float(x['optimum'])+1e-7 for x in co)
files=['summary.json','inverse_diffusion_trials.csv','transient_queue_trials.csv','correlated_test_selection_trials.csv','queue_monte_carlo_checks.json']
checksums={p:hashlib.sha256((DATA/p).read_bytes()).hexdigest() for p in files}
report={'audited_rows':540,'independent_aggregate_checks':'PASS','queue_monte_carlo_checks':10,
        'files_sha256':checksums}
(DATA/'audit.json').write_text(json.dumps(report,indent=2)+'\n')
print('PASS - independent reaggregation of all 540 synthetic study records')
print('PASS - full row count, exact score bounds, Monte Carlo checks, file hashes')

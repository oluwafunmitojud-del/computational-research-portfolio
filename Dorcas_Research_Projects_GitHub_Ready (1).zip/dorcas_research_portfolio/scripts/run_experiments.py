"""Generate every published number, CSV and figure with fixed random seeds.

Usage: PYTHONPATH=src python scripts/run_experiments.py
Please cite this as a synthetic, computational demonstration, not peer-reviewed work.
"""
from pathlib import Path
import sys, os, csv, json, platform
import numpy as np
from scipy import __version__ as scipy_version
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from dorcas_research.inverse_diffusion import DiffusionModel,scenario
from dorcas_research.transient_queue import (propagate, block_risk,stationary_mean_rate_approx,
                                              simulate_risk, choose_capacity)
from dorcas_research.correlated_testing import generate_portfolio,sample_trial

ROOT=Path(__file__).resolve().parents[1]
(RESULTS:=ROOT/'results').mkdir(exist_ok=True)
(FIGURES:=ROOT/'figures').mkdir(exist_ok=True)
plt.rcParams.update({"figure.dpi":150,"savefig.dpi":180,"font.size":10,"axes.spines.top":False,"axes.spines.right":False})


def writecsv(name,rows):
    with (RESULTS/name).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=rows[0].keys())
        w.writeheader();w.writerows(rows)

def asnum(x):
    return round(float(x),8)

def study_inverse():
    rng=np.random.default_rng(20261020)
    model=DiffusionModel(10)
    rows=[]
    for m in (8,16,28):
        for iteration in range(40):
            r=scenario(model,rng,sensor_count=m,noise_fraction=.14,ridge=.07)
            rows.append({"replicate":iteration,"sensors":m,**{k:asnum(v) if not isinstance(v,bool) else v for k,v in r.items()}})
    writecsv('inverse_diffusion_trials.csv',rows)
    all_reg=np.array([r['error_regularized'] for r in rows])
    all_base=np.array([r['error_unregularized'] for r in rows])
    means={}
    for m in (8,16,28):
        sample=[r for r in rows if r['sensors']==m]
        means[m]={"ridge_median":asnum(np.median([r['error_regularized'] for r in sample])),
                  "unregularized_median":asnum(np.median([r['error_unregularized'] for r in sample])),
                  "median_singular_value":asnum(np.median([r['jacobian_smallest_sv'] for r in sample]))}
    fig,ax=plt.subplots(figsize=(8,4.3))
    idx=np.arange(3)
    ax.bar(idx-.18,[means[m]['ridge_median'] for m in (8,16,28)],width=.36,label='Ridge')
    ax.bar(idx+.18,[means[m]['unregularized_median'] for m in (8,16,28)],width=.36,label='Unregularized')
    ax.set_xticks(idx,['8 sensors','16 sensors','28 sensors'])
    ax.set_ylabel('Median relative conductivity error (lower = better)')
    ax.set_title('Inverse diffusion: regularization and sensor coverage')
    ax.grid(axis='y',alpha=.2);ax.legend(frameon=False)
    fig.tight_layout();fig.savefig(FIGURES/'inverse_diffusion_comparison.png');plt.close(fig)

    theta=np.array([.28,-.28,.33,-.18]); sensors=rng.choice(100,16,False)
    y=model.observe(theta,sensors)
    s=.14*max(float(np.std(y)),.001)
    recon=model.fit(sensors,y+rng.normal(0,s,16),s,.07)
    fig,axes=plt.subplots(1,2,figsize=(9,3.8),sharex=True,sharey=True)
    kt=np.exp(model.B@theta).reshape(10,10)
    ke=np.exp(model.B@recon.x).reshape(10,10)
    vmin=min(kt.min(),ke.min());vmax=max(kt.max(),ke.max())
    for a,z,label in zip(axes,[kt,ke],['True synthetic conductivity','Reconstructed conductivity']):
        im=a.imshow(z.T,origin='lower',cmap='viridis',vmin=vmin,vmax=vmax,
                    extent=(0,1,0,1),interpolation='nearest')
        a.set_title(label);a.set_xlabel('x')
    axes[0].set_ylabel('y')
    fig.colorbar(im,ax=axes,shrink=.83,label='k(x,y)')
    fig.subplots_adjust(left=.07,right=.89,top=.9,bottom=.14,wspace=.18)
    fig.savefig(FIGURES/'inverse_diffusion_fields.png');plt.close(fig)
    return {"title":"Inverse diffusion and adjoint sensitivity", "trials":120,
            "median_ridge_error":asnum(np.median(all_reg)),
            "median_unregularized_error":asnum(np.median(all_base)),
            "ridge_better_fraction":asnum(np.mean(all_reg<all_base)),
            "by_sensor_count":means,
            "converged_ridge_count":sum(r['reg_success'] for r in rows),
            "converged_unregularized_count":sum(r['unreg_success'] for r in rows),
            "seed":20261020,"model_interior_grid":"10 x 10",
            "note":"Synthetic held-out parameter draws and noisy sensors; metric is relative L2 error in conductivity at grid nodes."}


def study_queue():
    rng=np.random.default_rng(20261021)
    rows=[]
    shapes=('constant','front_loaded','middle_burst','back_loaded')
    for shape in shapes:
        for j in range(30):
            base=float(rng.uniform(1.2,5.2))
            mu=float(rng.uniform(.9,2.6))
            servers=int(rng.integers(2,6))
            if shape=='constant':rates=[base]*3
            elif shape=='front_loaded':rates=[3*base,.6*base,.3*base]
            elif shape=='middle_burst':rates=[.45*base,2.8*base,.45*base]
            else:rates=[.3*base,.6*base,3*base]
            schedule=list(zip([1.,1.,1.],rates))
            p=propagate(schedule,mu,servers,servers+1)
            p_ref=propagate(schedule,mu,servers,servers+1,mode='expm')
            prediction=stationary_mean_rate_approx(schedule,mu,servers,buffer=1)
            rows.append({"shape":shape,"replicate":j,"mu":asnum(mu),"servers":servers,
                        "rate_1":asnum(rates[0]),"rate_2":asnum(rates[1]),"rate_3":asnum(rates[2]),
                        "transient_risk":asnum(p[-1]),"stationary_mean_rate_approx":asnum(prediction),
                        "absolute_stationary_error":asnum(abs(prediction-p[-1])),
                        "oracle_max_deviation":float(max(abs(p-p_ref))),
                        "conservation_residual":float(abs(p.sum()-1))})
    writecsv('transient_queue_trials.csv',rows)
    fig,axes=plt.subplots(1,2,figsize=(10.4,4))
    byshape=[]
    for sh in shapes:
        byshape.append([r['absolute_stationary_error'] for r in rows if r['shape']==sh])
    axes[0].boxplot(byshape, tick_labels=['constant','front','middle','back'],showfliers=False)
    axes[0].set_ylabel('Absolute risk error: stationary-rate approximation')
    axes[0].set_title('Transient vs mean-rate shortcut')
    axes[0].grid(axis='y',alpha=.2)
    schedule=[(1,.8),(1,8.5),(1,.8)]
    servers,mu=3,1.8
    risks=[block_risk(schedule,mu,c,1) for c in range(1,8)]
    base=[stationary_mean_rate_approx(schedule,mu,c,1) for c in range(1,8)]
    axes[1].plot(range(1,8),risks,marker='o',label='Piecewise transient CTMC')
    axes[1].plot(range(1,8),base,marker='s',linestyle='--',label='Mean-rate baseline')
    axes[1].set_ylabel('P(at least one blocked arrival)');axes[1].set_xlabel('Servers (K=c+1)')
    axes[1].set_title('Illustrative burst and capacity selection')
    axes[1].grid(alpha=.2);axes[1].legend(frameon=False,fontsize=8)
    fig.tight_layout();fig.savefig(FIGURES/'transient_queue_comparison.png');plt.close(fig)

    checks=[]
    # Independent stochastic check of ten fixed scenarios, not all 120 trials.
    for j in range(10):
        sched=[(.8,float(rng.uniform(.5,3.))),(.7,float(rng.uniform(5.,9.))),(1.,float(rng.uniform(.5,3.)))]
        mu=float(rng.uniform(1.,2.3)); c=int(rng.integers(2,5))
        analytic=block_risk(sched,mu,c,1)
        mc=simulate_risk(sched,mu,c,buffer=1,replications=6000,seed=2000+j)
        checks.append({"scenario":j,"analytic_risk":analytic,**mc,
                       "within_95_percent_interval":mc['lo95']<=analytic<=mc['hi95']})
    with (RESULTS/'queue_monte_carlo_checks.json').open('w') as f:
        json.dump(checks,f,indent=2)
    exact=np.array([r['transient_risk'] for r in rows]);approx=np.array([r['stationary_mean_rate_approx'] for r in rows])
    return {"title":"Transient stochastic queue reliability", "trials":120,
            "max_abs_probability_conservation_residual":float(max(r['conservation_residual'] for r in rows)),
            "max_abs_uniformization_vs_expm_error":float(max(r['oracle_max_deviation'] for r in rows)),
            "median_abs_mean_rate_risk_error":asnum(np.median(abs(approx-exact))),
            "mean_rate_error_over_5_percent_fraction":asnum(np.mean(abs(approx-exact)>.05)),
            "monte_carlo_checks":len(checks),"mc_95pct_coverage_count":sum(x['within_95_percent_interval'] for x in checks),
            "seed":20261021,
            "note":"All queues start empty; risk is P(first blocked arrival by T), not stationary full-state mass."}


def study_correlated():
    rng=np.random.default_rng(20261022)
    rows=[]
    for i in range(300):
        port=generate_portfolio(rng,n=10,dependence='strong')
        r=sample_trial(port)
        rows.append({"replicate":i,"optimum":asnum(r['optimal']),
                     "correlation_aware":asnum(r['correlated']),
                     "independence_assuming":asnum(r['independent']),
                     "aware_fraction_of_optimum":asnum(r['correlated_fraction']),
                     "independent_fraction_of_optimum":asnum(r['independent_fraction']),
                     "aware_subset":' '.join(map(str,r['correlated_subset'])),
                     "independent_subset":' '.join(map(str,r['independent_subset'])),
                     "number_feasible_subsets":r['feasible_count']})
    writecsv('correlated_test_selection_trials.csv',rows)
    aware=np.array([r['aware_fraction_of_optimum'] for r in rows])
    naive=np.array([r['independent_fraction_of_optimum'] for r in rows])
    fig,axes=plt.subplots(1,2,figsize=(9.5,4.1))
    axes[0].boxplot([aware,naive],tick_labels=['Latent-aware greedy','Marginal greedy'])
    axes[0].set_ylabel('Fraction of exact optimum')
    axes[0].set_ylim(.45,1.03)
    axes[0].set_title('300 seeded constrained test portfolios')
    axes[0].grid(axis='y',alpha=.25)
    axes[1].hist(aware-naive,bins=18)
    axes[1].set_xlabel('Aware fraction - marginal fraction')
    axes[1].set_ylabel('Number of portfolios')
    axes[1].set_title('Benefit depends on the portfolio')
    axes[1].axvline(0,color='black',linewidth=1)
    fig.tight_layout();fig.savefig(FIGURES/'correlated_testing_comparison.png');plt.close(fig)
    return {"title":"Correlated fault regression-test optimization", "trials":300,
            "mean_aware_fraction_of_exact_optimum":asnum(aware.mean()),
            "mean_naive_fraction_of_exact_optimum":asnum(naive.mean()),
            "aware_wins":int(np.sum(aware>naive+1e-10)),
            "naive_wins":int(np.sum(naive>aware+1e-10)),
            "ties":int(np.sum(abs(aware-naive)<=1e-10)),
            "worst_aware_fraction":asnum(aware.min()),
            "worst_naive_fraction":asnum(naive.min()),
            "seed":20261022,
            "note":"Outcomes are evaluated under the true latent-regime model, with exact subset enumeration on each 10-test portfolio."}


def main():
    print('Study 1: 120 inverse reconstructions',flush=True)
    inverse=study_inverse()
    print(json.dumps(inverse,indent=2),flush=True)
    print('Study 2: 120 queue configurations plus 10 Monte Carlo crosschecks',flush=True)
    queues=study_queue()
    print(json.dumps(queues,indent=2),flush=True)
    print('Study 3: 300 correlated selection portfolios',flush=True)
    testing=study_correlated()
    print(json.dumps(testing,indent=2),flush=True)
    summary={"type":"independent synthetic computational studies", "research_status":"reproducible educational demonstrations, not peer-reviewed publications",
             "software":{"python":sys.version.split()[0],"numpy":np.__version__,"scipy":scipy_version},
             "inverse_diffusion":inverse,"transient_queue":queues,"correlated_testing":testing}
    with (RESULTS/'summary.json').open('w') as f:
        json.dump(summary,f,indent=2)
    print('Wrote summary.json, source trials and figure files.',flush=True)

if __name__=='__main__':
    main()

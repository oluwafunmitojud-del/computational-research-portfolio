# CV-ready project descriptions — use after verifying and publishing

Keep academic and employment dates separate: these are **2026 synthetic portfolio demonstrations**, not evidence of earlier academic research appointments.

**Independent Computational Research Portfolio | 2026**

- **Inverse Diffusion and Adjoint Sensitivity (Python, SciPy).** Implemented a sparse elliptic forward model and discrete-adjoint gradient; 120 seeded synthetic inversions produced median relative conductivity errors of 0.1158 with ridge regularization versus 0.1333 without, with independent finite-difference gradient checks.
- **Transient Stochastic Queue Reliability (CTMCs, Monte Carlo).** Built a piecewise-stationary Markov queue model with absorbing first-loss events, Poisson uniformization and matrix-exponential verification; numerical methods agreed within 2.4 × 10^-13 across 120 synthetic configurations.
- **Correlated-Fault Regression-Test Selection (Optimization, Probability).** Developed a latent-regime expected-detection objective with time and false-alert budgets, verified against exact enumeration; mean quality was 98.69% of the exact optimum over 300 synthetic 10-test portfolios.

**Code:** `https://github.com/YOUR-USERNAME/computational-research-portfolio` (replace only after publishing)

**Portfolio:** `https://YOUR-USERNAME.github.io/computational-research-portfolio/` or actual Google Sites URL (replace only after publishing)

**Integrity note:** These findings describe a newly created, AI-assisted, reproducible synthetic portfolio, not historical research, former employer projects, or published academic output. Only claim personally completed and understood work.

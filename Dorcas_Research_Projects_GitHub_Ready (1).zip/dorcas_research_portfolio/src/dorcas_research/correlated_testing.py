"""Fault-test portfolio optimization under shared latent environments.

Conditionally on environment z and fault d, test outcomes are independent;
unconditionally the detections are correlated through the common latent state.
This is a scenario model, not a fitted real-world production fault model.
"""
from dataclasses import dataclass
import numpy as np


@dataclass
class TestPortfolio:
    __test__ = False  # This is a model type, not a pytest test class.
    weights: np.ndarray       # shape (regimes,)
    severity: np.ndarray      # shape (faults,)
    probabilities: np.ndarray # shape (tests, regimes, faults)
    runtimes: np.ndarray      # shape (tests,)
    false_alarm: np.ndarray   # expected false alerts, additive budget
    time_budget: float
    alarm_budget: float

    def __post_init__(self):
        self.weights=np.asarray(self.weights,float)
        self.severity=np.asarray(self.severity,float)
        self.probabilities=np.asarray(self.probabilities,float)
        self.runtimes=np.asarray(self.runtimes,float)
        self.false_alarm=np.asarray(self.false_alarm,float)
        N,Z,D=self.probabilities.shape
        if (self.weights.shape!=(Z,) or self.severity.shape!=(D,) or
            self.runtimes.shape!=(N,) or self.false_alarm.shape!=(N,)):
            raise ValueError("inconsistent portfolio dimensions")
        if (not np.isclose(self.weights.sum(),1) or np.any(self.weights<0) or
            np.any(self.probabilities<0) or np.any(self.probabilities>1) or
            np.any(self.runtimes<=0) or np.any(self.false_alarm<0) or
            self.time_budget<=0 or self.alarm_budget<=0 or np.any(self.severity<0)):
            raise ValueError("invalid probability or cost inputs")

    @property
    def n(self):
        return len(self.runtimes)

    def feasible(self,chosen):
        chosen=np.array(list(chosen),int)
        return (self.runtimes[chosen].sum()<=self.time_budget+1e-10 and
                self.false_alarm[chosen].sum()<=self.alarm_budget+1e-10)

    def value(self,chosen,assume_independent=False):
        chosen=list(chosen)
        if not chosen:
            return 0.
        if assume_independent:
            marg=np.einsum('z,tzd->td',self.weights,self.probabilities)
            chance=1-np.prod(1-marg[chosen],axis=0)
        else:
            chance=np.einsum('z,zd->d',self.weights,1-np.prod(1-self.probabilities[chosen],axis=0))
        return float(np.dot(self.severity,chance))

    def oracle(self):
        """Exact enumeration restricted to at most 16 tests; verification oracle."""
        if self.n>16:
            raise ValueError("exact oracle limited to at most 16 tests")
        N=self.n
        count=1<<N
        fail=np.ones((count,len(self.weights),len(self.severity)))
        runtime=np.zeros(count)
        alarm=np.zeros(count)
        for mask in range(1,count):
            bit=mask & -mask
            j=bit.bit_length()-1
            previous=mask^bit
            fail[mask]=fail[previous]*(1-self.probabilities[j])
            runtime[mask]=runtime[previous]+self.runtimes[j]
            alarm[mask]=alarm[previous]+self.false_alarm[j]
        value=np.einsum('z,d,mzd->m',self.weights,self.severity,1-fail)
        feasible=(runtime<=self.time_budget+1e-10)&(alarm<=self.alarm_budget+1e-10)
        best=int(np.argmax(np.where(feasible,value,-np.inf)))
        return {"subset":[i for i in range(N) if best & (1<<i)],
                "value":float(value[best]), "feasible_count":int(feasible.sum())}

    def greedy(self,assume_independent=False):
        chosen=[]
        remaining=set(range(self.n))
        while remaining:
            candidates=[]
            for t in sorted(remaining):
                subset=chosen+[t]
                if not self.feasible(subset):
                    continue
                gain=self.value(subset,assume_independent)-self.value(chosen,assume_independent)
                cost=(self.runtimes[t]/self.time_budget +
                      self.false_alarm[t]/self.alarm_budget)/2
                candidates.append((gain/max(cost,1e-12),gain,-t,t))
            if not candidates:
                break
            _,gain,_,pick=max(candidates)
            if gain<=0:
                break
            chosen.append(pick)
            remaining.remove(pick)
        # Compare to best single feasible test: ratio-greedy can miss large items.
        singles=[i for i in range(self.n) if self.feasible([i])]
        if singles:
            best=max(singles,key=lambda i:self.value([i],assume_independent))
            if self.value([best],assume_independent)>self.value(chosen,assume_independent):
                chosen=[best]
        return {"subset":sorted(chosen),"value":self.value(chosen),
                "modeled_value":self.value(chosen,assume_independent)}


def generate_portfolio(rng,n=10,dependence="strong"):
    Z,D=3,5
    weights=np.array([.35,.4,.25])
    severity=rng.uniform(.7,2.5,size=D)
    affinity=rng.beta(2.0,2.4,size=(n,D))
    regime_factor=np.array([1.55,.55,.15]) if dependence=="strong" else np.array([1.,.95,.9])
    # Some specialist tests retain higher detection probability in adverse regimes.
    specialists=rng.choice(n,size=max(n//4,1),replace=False)
    probs=np.empty((n,Z,D))
    for z in range(Z):
        probs[:,z,:]=affinity*regime_factor[z]
    probs[specialists,2,:]+=rng.uniform(.15,.6,size=(len(specialists),D))
    probs=np.clip(probs,.002,.985)
    durations=rng.integers(1,6,size=n).astype(float)
    alarms=rng.uniform(.01,.08,size=n)
    return TestPortfolio(weights,severity,probs,durations,alarms,
                         time_budget=float(durations.sum()*.32),
                         alarm_budget=float(alarms.sum()*.36))


def sample_trial(portfolio):
    optimal=portfolio.oracle()
    corr=portfolio.greedy()
    independent=portfolio.greedy(assume_independent=True)
    return {"optimal":optimal["value"],"correlated":corr["value"],
            "independent":independent["value"],
            "correlated_fraction":corr["value"]/optimal["value"] if optimal["value"] else 1.,
            "independent_fraction":independent["value"]/optimal["value"] if optimal["value"] else 1.,
            "correlated_subset":corr["subset"],
            "independent_subset":independent["subset"],
            "feasible_count":optimal["feasible_count"]}

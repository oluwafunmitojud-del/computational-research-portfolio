"""Three small, independently reproducible synthetic computational research studies.

No external datasets, proprietary material or claims of institutional affiliation.
"""
__version__ = "1.0.0"

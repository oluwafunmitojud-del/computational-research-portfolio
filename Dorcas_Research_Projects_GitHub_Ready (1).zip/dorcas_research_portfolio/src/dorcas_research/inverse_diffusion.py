"""Sparse-sensor inverse diffusion using a graph-conservative 2-D elliptic operator.

The unit square is discretized at n x n interior nodes. Boundary values are zero.
Conductivity is exp(B theta) where B holds four smooth spatial basis fields.
The edge formulation makes the operator symmetric positive definite for k>0.
"""
from dataclasses import dataclass
import numpy as np
from scipy import sparse
from scipy.optimize import minimize
from scipy.sparse.linalg import spsolve


@dataclass
class DiffusionModel:
    n: int = 10

    def __post_init__(self):
        if self.n < 3:
            raise ValueError("grid requires at least 3 interior points on each side")
        self.h = 1.0 / (self.n + 1)
        x, y = np.meshgrid(np.arange(1, self.n + 1)*self.h,
                           np.arange(1, self.n + 1)*self.h, indexing="ij")
        self.x, self.y = x.ravel(), y.ravel()
        centers = [(0.27, .27), (.73, .27), (.27, .73), (.73, .73)]
        self.B = np.column_stack([
            np.exp(-((self.x-cx)**2 + (self.y-cy)**2)/(.24**2))
            for cx, cy in centers
        ])
        pairs = []
        boundary_count = np.zeros(self.n*self.n)
        for i in range(self.n):
            for j in range(self.n):
                q = i*self.n + j
                if i+1 < self.n:
                    pairs.append((q, (i+1)*self.n+j))
                if j+1 < self.n:
                    pairs.append((q, i*self.n+j+1))
                boundary_count[q] += (i==0)+(i==self.n-1)+(j==0)+(j==self.n-1)
        self.pairs = np.array(pairs, dtype=int)
        self.i, self.j = self.pairs[:, 0], self.pairs[:, 1]
        self.boundary_count = boundary_count
        self.f = (10.0*np.exp(-((self.x-.38)**2+(self.y-.52)**2)/.055)
                  + 7.5*np.exp(-((self.x-.72)**2+(self.y-.33)**2)/.035))

    def assemble(self, theta, with_derivatives=False):
        theta = np.asarray(theta, float)
        if theta.shape != (4,):
            raise ValueError("theta must have four parameters")
        k = np.exp(self.B@theta)
        a, b = k[self.i], k[self.j]
        g = (2*a*b/(a+b)) / self.h**2
        bd = self.boundary_count*k/self.h**2
        diagonal = np.bincount(self.i, weights=g, minlength=len(k)) + np.bincount(
            self.j, weights=g, minlength=len(k)) + bd
        rows = np.concatenate((self.i,self.j,np.arange(len(k))))
        cols = np.concatenate((self.j,self.i,np.arange(len(k))))
        data = np.concatenate((-g,-g,diagonal))
        A = sparse.coo_matrix((data,(rows,cols)), shape=(len(k),len(k))).tocsr()
        if not with_derivatives:
            return A
        # d(log g)/d(theta) for the harmonic-mean conductivity at a face.
        face_basis = (b[:,None]*self.B[self.i] + a[:,None]*self.B[self.j])/(a+b)[:,None]
        d_g = g[:,None]*face_basis
        d_bd = (self.boundary_count*k/self.h**2)[:,None]*self.B
        return A, d_g, d_bd

    def state(self, theta):
        return spsolve(self.assemble(theta), self.f)

    def observe(self, theta, sensors):
        return self.state(theta)[np.asarray(sensors, dtype=int)]

    def objective_and_gradient(self, theta, sensors, observations, sigma, ridge):
        if sigma <= 0 or ridge < 0:
            raise ValueError("sigma must be positive and ridge nonnegative")
        sensors = np.asarray(sensors, dtype=int)
        if not len(sensors):
            raise ValueError("at least one sensor is required")
        A, dg, dbd = self.assemble(theta, with_derivatives=True)
        u = spsolve(A,self.f)
        r = u[sensors]-np.asarray(observations)
        scale = 1/(len(sensors)*sigma**2)
        objective = .5*scale*np.dot(r,r)+.5*ridge*np.dot(theta,theta)
        rhs = np.bincount(sensors, weights=scale*r, minlength=len(u))
        adj = spsolve(A.T,rhs)
        grad = (-np.sum(dg*(adj[self.i]-adj[self.j])[:,None]*(u[self.i]-u[self.j])[:,None],axis=0)
                -np.sum(dbd*adj[:,None]*u[:,None],axis=0)
                + ridge*np.asarray(theta))
        return float(objective), np.asarray(grad)

    def fit(self, sensors, observations, sigma, ridge=0.1):
        res = minimize(lambda t: self.objective_and_gradient(t,sensors,observations,sigma,ridge),
                       x0=np.zeros(4), method="L-BFGS-B", jac=True, bounds=[(-1.2,1.2)]*4,
                       options={"maxiter":150,"ftol":1e-12,"gtol":1e-8})
        return res

    def observation_jacobian(self, theta, sensors, epsilon=1e-5):
        sensors = np.asarray(sensors,dtype=int)
        return np.column_stack([(self.observe(np.asarray(theta)+epsilon*np.eye(4)[i],sensors)
                                 -self.observe(np.asarray(theta)-epsilon*np.eye(4)[i],sensors))/(2*epsilon)
                                for i in range(4)])

    def conductivity_error(self, theta_est, theta_true):
        a,b = np.exp(self.B@theta_est), np.exp(self.B@theta_true)
        return float(np.linalg.norm(a-b)/np.linalg.norm(b))


def scenario(model, rng, sensor_count=16, noise_fraction=0.12, ridge=0.06):
    theta_true = rng.normal(0, .34, size=4)
    sensors = rng.choice(model.n**2, size=sensor_count, replace=False)
    true_obs = model.observe(theta_true,sensors)
    sigma = noise_fraction*max(float(np.std(true_obs)),.001)
    obs = true_obs+rng.normal(0,sigma,size=sensor_count)
    regularized = model.fit(sensors,obs,sigma,ridge)
    unregularized = model.fit(sensors,obs,sigma,0)
    J = model.observation_jacobian(theta_true,sensors)/sigma
    sv = np.linalg.svd(J,compute_uv=False)
    return {
        "error_regularized":model.conductivity_error(regularized.x,theta_true),
        "error_unregularized":model.conductivity_error(unregularized.x,theta_true),
        "jacobian_condition":float(sv[0]/max(sv[-1],1e-14)),
        "jacobian_smallest_sv":float(sv[-1]),
        "reg_success":bool(regularized.success),
        "unreg_success":bool(unregularized.success),
        "gradient_norm":float(np.linalg.norm(regularized.jac)),
    }

"""Piecewise constant nonstationary finite-capacity M/M/c/K loss models.

The extra absorbing state records the *first* blocked arrival, so the reported
risk is P(at least one arrival was blocked before the horizon), not P(queue full).
Analytic propagation uses Poisson uniformization with an explicit Poisson-tail
bound; an independent matrix-exponential oracle and Gillespie simulator exist.
"""
import math
import numpy as np
from scipy.linalg import expm
from scipy.stats import poisson


def generator(arrival_rate:float, mu:float, servers:int, capacity:int):
    if min(arrival_rate,mu)<0 or servers<1 or capacity<servers:
        raise ValueError("invalid rates, server count or capacity")
    Q = np.zeros((capacity+2,capacity+2))
    lost = capacity+1
    for n in range(capacity+1):
        if n < capacity:
            Q[n,n+1] += arrival_rate
        else:
            Q[n,lost] += arrival_rate
        if n:
            Q[n,n-1] += min(n,servers)*mu
        Q[n,n] = -np.sum(Q[n])
    return Q


def uniformize(p, Q, dt, tolerance=1e-13):
    if dt < 0 or tolerance<=0 or tolerance>=1:
        raise ValueError("invalid time or tolerance")
    p = np.asarray(p,dtype=float)
    if dt == 0:
        return p.copy()
    q = float(np.max(-np.diag(Q)))
    if q == 0:
        return p.copy()
    # Chunk to bound q*dt, avoid e^-qdt underflow, and control Poisson truncation.
    pieces = max(1, math.ceil(q*dt/20))
    for _ in range(pieces):
        z = q*dt/pieces
        P = np.eye(len(p))+Q/q
        v = p.copy()
        weight = math.exp(-z)
        result = weight*v
        for n in range(1,500):
            v = v@P
            weight *= z/n
            result += weight*v
            if poisson.sf(n,z) < tolerance/pieces:
                break
        else:
            raise RuntimeError("Poisson series failed to converge")
        p = result
    return p


def propagate(schedule, mu, servers, capacity, mode="uniformization", initial=None):
    p = np.zeros(capacity+2)
    if initial is None:
        p[0]=1
    else:
        p = np.asarray(initial,float).copy()
    for duration,arrival_rate in schedule:
        if duration<0:
            raise ValueError("segment duration must be nonnegative")
        Q = generator(arrival_rate,mu,servers,capacity)
        if mode=="uniformization":
            p=uniformize(p,Q,duration)
        elif mode=="expm":
            p=p@expm(Q*duration)
        else:
            raise ValueError("mode must be 'uniformization' or 'expm'")
    return p


def block_risk(schedule, mu, servers, buffer=1, mode="uniformization"):
    return float(propagate(schedule,mu,servers,servers+buffer,mode=mode)[-1])


def stationary_mean_rate_approx(schedule, mu, servers, buffer=1):
    """Deliberately simplistic baseline, not an exact time-dependent solution.

    pi is stationary for the constant *time averaged* birth rate and death rates;
    risk is approximated by Poisson arrivals thinned by stationary full-state mass.
    It neglects startup transients and correlation of repeated full-state arrivals.
    """
    T = sum(d for d,_ in schedule)
    if T<=0:
        return 0.
    lam = sum(d*r for d,r in schedule)/T
    K = servers+buffer
    if lam==0:
        return 0.
    weights = np.ones(K+1)
    for n in range(1,K+1):
        weights[n] = weights[n-1]*lam/(min(n,servers)*mu)
    pi = weights/weights.sum()
    return float(1-np.exp(-lam*T*pi[-1]))


def simulate_once(schedule, mu, servers, capacity, rng):
    """Independent exact event-driven simulation with piecewise rates."""
    n=0
    for duration, lam in schedule:
        t=0.
        while t<duration:
            rate=lam+min(n,servers)*mu
            if rate==0:
                break
            t+=rng.exponential(1./rate)
            if t>=duration:
                break
            if rng.random()<lam/rate:
                if n>=capacity:
                    return True
                n+=1
            else:
                n-=1
    return False


def simulate_risk(schedule,mu,servers,buffer=1,replications=5000,seed=1):
    rng=np.random.default_rng(seed)
    trials = sum(simulate_once(schedule,mu,servers,servers+buffer,rng)
                 for _ in range(replications))
    p=trials/replications
    z=1.96
    # Wilson 95% interval
    den=1+z*z/replications
    center=(p+z*z/(2*replications))/den
    half=z*math.sqrt(p*(1-p)/replications+z*z/(4*replications**2))/den
    return {"estimate":float(p),"lo95":float(max(center-half,0)),
            "hi95":float(min(center+half,1)),"replications":replications}


def choose_capacity(schedule,mu,max_servers=9,buffer=1,risk_limit=.18):
    for c in range(1,max_servers+1):
        risk=block_risk(schedule,mu,c,buffer)
        if risk<=risk_limit:
            return {"servers":c,"risk":risk,"feasible":True}
    return {"servers":None,"risk":block_risk(schedule,mu,max_servers,buffer),"feasible":False}

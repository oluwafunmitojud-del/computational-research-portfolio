# Copy-ready text for your Google Sites portfolio

**Site title:** Dorcas Oluwafunmitoju | Computational Research Portfolio

**Introduction**

My computational research portfolio presents three independently reproducible Python demonstrations in inverse problems, transient stochastic systems and constrained optimization. Each project includes a mathematical problem formulation, Python implementation, seeded synthetic experiments, automated tests, transparent comparison methods and a written discussion of assumptions and limitations. These studies are educational portfolio demonstrations, not peer-reviewed papers or research performed for an employer.

## Project 1 — Inverse Diffusion and Adjoint Sensitivity

**Research question:** Can a noisy sparse sensor network recover the conductivity field of an elliptic diffusion model, and when does regularization help? I implemented a sparse finite-difference forward solver, a discrete-adjoint gradient, and a finite-difference gradient cross-check. Across 120 fixed synthetic trials, median relative conductivity error was 0.1158 with ridge regularization, compared with 0.1333 without. The study also compares 8, 16 and 28 sensor deployments.

**Images to upload:** `figures/inverse_diffusion_comparison.png` and `figures/inverse_diffusion_fields.png`.

## Project 2 — Transient Queue Reliability and Capacity

**Research question:** How misleading can stationary assumptions be for a bursty, short-horizon queue? I built a time-varying finite-capacity CTMC with an absorbing first-loss state, solved it with Poisson uniformization and checked the result against an independent matrix-exponential computation and event-driven simulation. Across 120 synthetic configurations, the median absolute error of the mean-rate shortcut was 0.0730 probability units.

**Image to upload:** `figures/transient_queue_comparison.png`.

## Project 3 — Correlated-Fault Regression-Test Optimization

**Research question:** Which tests should be selected when fault-detection outcomes share latent conditions and both runtime and false-alarm budgets matter? I implemented a latent-regime detection objective, exact search for small cases, and comparable constrained greedy policies. On 300 synthetic 10-test portfolios, correlation-aware greedy achieved 98.69% of the exact optimum on average, versus 97.10% for a marginal-independence approach.

**Image to upload:** `figures/correlated_testing_comparison.png`.

## Reproducibility

Every project includes readable Python source code, unit tests, fixed random seeds, raw experimental CSVs, charts and a report. A combined suite of 55 automated test cases passed locally. The studies were developed with AI assistance and should be presented transparently; they do not establish my academic records, employment history or peer-reviewed publication status.

**Contact:** oluwafunmitojud@gmail.com

**LinkedIn:** https://www.linkedin.com/in/dorcas-oluwafunmitoju-60476a444

**GitHub project:** [Add the real URL after you publish to your own GitHub account]

**Full study report:** [Add its public GitHub Pages or shared Google Drive URL after publishing]

## Suggested Google Sites layout

Use a homepage with a short introduction, one section per study, one chart per section, and a final “Reproducibility & Contact” section. Paste the text above and upload the PNG charts. The ready-made `docs/index.html` provides a styled preview, but Google Sites does not automatically convert local HTML into an editable Google Sites page.

# Study 02 — Transient Stochastic Queue Reliability and Capacity

## Research question

When does a stationary or mean-rate assumption misstate the probability of losing at least one job during a short bursty arrival horizon?

## Queueing model

Use a finite-capacity `M(t)/M/c/K` system: capacity `K = c + 1` by default, `c` parallel exponential servers each with service rate `mu`, and piecewise constant Poisson arrival rates `lambda(t)`. All queues **start empty**. Occupancy states are `n=0,...,K` with an additional **absorbing first-loss state**, entered on an arrival while `n=K`. The target risk is `P(at least one blocked arrival before the horizon)`, **not** `P(occupancy=K at T)` and not an expected number of losses.

For `n < K`, the arrival transition `n -> n+1` has rate `lambda(t)`; for `n > 0` a departure `n -> n-1` has rate `min(n,c)mu`; from the full state `K`, arrivals move to the absorbing event state. The generator `Q` has nonnegative off-diagonal entries and row sums zero.

## Numerical methods and independent cross-checks

**Primary:** piecewise uniformization (`P=I+Q/q`, `q=max(-Q_ii)`) and a Poisson-weighted series. Long intervals are subdivided to keep `q*dt` <= approximately 20; a Poisson survival-function tail bound terminates the series below the specified tolerance.

**Independent numerical reference:** per-segment dense matrix exponential `p @ expm(Q dt)`, which does not call uniformization.

**Stochastic reference:** direct Gillespie event simulation, with rates reset at schedule boundaries. Monte Carlo proportions are reported with Wilson 95% intervals.

**Simple shortcut baseline (intentionally approximate):** calculate a stationary finite-capacity distribution using the average arrival rate, then take `1-exp(-lambda_mean*T*pi_K)` as a Poisson-thinning approximation. This baseline ignores initial-state transients, time ordering of bursts, and dependence across attempts.

## Experiment

120 seeded synthetic configurations: four arrival profiles (`constant`, `front_loaded`, `middle_burst`, and `back_loaded`) with 30 parameter draws each. Three unit-duration segments; base arrival rate from uniform `[1.2,5.2]`, service rate from uniform `[0.9,2.6]`, and 2–5 servers. Ten **additional** randomly specified scenarios receive 6,000-path event simulation checks each. Seed `20261021` for the configurations.

## Measured results

- Maximum probability-conservation residual across 120 scenarios: **2.83e-13**.
- Maximum difference between uniformization and dense matrix exponential: **2.36e-13**.
- Median absolute difference in predicted first-loss risk between transient model and shortcut: **0.07301** probability units.
- **60.83%** of configurations had a shortcut error exceeding 0.05 probability units.
- Analytic first-loss risk fell within the observed Wilson 95% Monte Carlo intervals in **10 of 10** selected cross-checks. This is a check, not proof of universal interval calibration.

Full 120-case values: `results/transient_queue_trials.csv`; ten direct event-simulation comparisons: `results/queue_monte_carlo_checks.json`; chart: `figures/transient_queue_comparison.png`.

## Interpretation and limitations

The experiment is a synthetic counterexample study, not a fitted service-level forecast. Arrivals are Poisson only **within each segment**, service time is memoryless and homogeneous across servers, and queues begin empty. Many production systems have retry behavior, heterogeneous service and time-dependent scheduling. The stationary shortcut is **not** a competing exact queueing algorithm; it is a transparent deliberately simplified planning heuristic.

## Reproduce

`PYTHONPATH=src python scripts/run_experiments.py` and `PYTHONPATH=src pytest -q tests/test_transient_queue.py`.

# Study 01 — Inverse Diffusion and Adjoint Sensitivity

## Research question

How does sensor count interact with inverse-problem identifiability and Tikhonov regularization when inferring a spatially varying conductivity from noisy field measurements?

## Model and discretization

Solve the synthetic elliptic equation `-div(k(x,y) grad u) = f` on the unit square with a zero Dirichlet boundary. Discretize on a 10x10 interior grid. Build the stiffness matrix by summing symmetric edge conductances between neighboring nodes. At an interior edge, the conductivity is the **harmonic mean** of the adjacent node values; boundary edges contribute positive diagonal terms. This produces a symmetric positive definite sparse matrix for strictly positive conductivity.

The unknown conductivity is a four-parameter exponential field `k = exp(B theta)` formed from Gaussian spatial basis functions. Solving the forward model at selected interior sensor coordinates produces predictions. Observations are corrupted by independent zero-mean Gaussian noise, with standard deviation equal to 14% of the sensor response standard deviation (floored by a documented 0.001 scale).

Minimize `0.5 * ||S u(theta) - y||^2 / (m sigma^2) + 0.5 lambda ||theta||^2` with `lambda = 0.07`, subject to box bounds `theta_j in [-1.2,1.2]`. Compare with the same constrained problem at `lambda = 0`. The state equation is `A(theta)u = f`.

## Adjoint gradient

Set `r = S u - y`, and solve `A^T p = S^T r/(m sigma^2)`. The derivative is

`grad_theta J = - p^T (partial A / partial theta) u + lambda theta`.

The implementation evaluates `p^T dA u` by summing edge-based and boundary-based contributions, without assembling a separate sparse `dA` per parameter. The face-conductance derivative correctly differentiates the harmonic mean. **The adjoint formula is independently verified** against centered finite differences with 8 different random parameters and observations. Tests also check positive definiteness and exact algebraic residuals of the forward solution.

## Experiment

- 120 seeded held-out synthetic cases, 40 each with 8, 16, or 28 randomly selected sensors.
- Four true conductivity parameters sampled independently from `N(0,0.34^2)`.
- Random seed `20261020`, interior grid 10x10, ridge penalty 0.07, noise fraction 0.14.
- Both methods use the same measured sensor values and same solver bounds.
- Metric: relative `L2` error `||k_est - k_true||_2 / ||k_true||_2` evaluated on the interior grid (smaller is better).
- Singular values of the finite-difference observation Jacobian are recorded as a local identifiability indicator.

## Measured results

| Sensors | Median ridge error | Median unregularized error |
|---|---:|---:|
| 8 | 0.20347 | 0.29786 |
| 16 | 0.11581 | 0.13657 |
| 28 | 0.07964 | 0.09373 |

Across all 120 cases, median ridge error was **0.11581** vs **0.13328** without regularization. Ridge was better in **85%** of these cases. The unregularized L-BFGS-B optimizer reported convergence in 119/120; the ridge optimizer converged in all 120.

Figures: `figures/inverse_diffusion_comparison.png` and `figures/inverse_diffusion_fields.png`. Every trial's unrounded method output is represented (to 8 decimals) in `results/inverse_diffusion_trials.csv`.

## Interpretation and limitations

The chosen noise, low-dimensional parameterization, smooth source field, regularization weight and bounded optimization favor this configuration. The results do **not** prove ridge always outperforms unregularized inversion. Real conductivities may be discontinuous, high-dimensional, nonidentifiable, or governed by uncertain boundary conditions. Synthetic reconstructions should not be described as validation on field measurements.

## Reproduce and audit

`PYTHONPATH=src python scripts/run_experiments.py` regenerates the CSV and figures. `PYTHONPATH=src pytest -q tests/test_inverse_diffusion.py` exercises algebraic and differential oracles. See `results/summary.json` for the machine-readable summary.

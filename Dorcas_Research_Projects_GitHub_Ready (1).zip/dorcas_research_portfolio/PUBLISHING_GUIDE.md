# Publishing the projects under your own name

**Nothing in this package has been published to GitHub or Google Sites yet.** The materials are packaged for publishing under your own GitHub account. Do not publish them under an account that you do not control.

## GitHub — create the real source-code URL

1. Sign in at https://github.com with **your own GitHub account**. If necessary, create a free account. Your profile link will then be `https://github.com/YOUR-USERNAME`.
2. Click **New repository**. Set the repository name to `computational-research-portfolio`, set visibility to **Public** only if you want employers to see it, and create it without adding a duplicate README.
3. Extract this ZIP. On the new repository page choose **uploading an existing file**, then upload the contents of the `dorcas_research_portfolio/` folder, including `src/`, `tests/`, `scripts/`, `results/`, `figures/`, `docs/`, `pyproject.toml` and the Markdown files. GitHub's browser uploader may make bulk folders tedious; `git` from the terminal is often easier:

   ```bash
   cd dorcas_research_portfolio
   git init
   git add .
   git commit -m "Publish reproducible computational research studies"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/computational-research-portfolio.git
   git push -u origin main
   ```

4. Verify the README, source code, tests, CSV results and charts appear in the online repository. Your **real GitHub project URL** is `https://github.com/YOUR-USERNAME/computational-research-portfolio`.
5. For a browsable portfolio website, open repository **Settings > Pages**. Choose **Deploy from a branch**, branch `main`, folder `/docs`, and save. Once GitHub publishes it, the site's URL will usually be `https://YOUR-USERNAME.github.io/computational-research-portfolio/`. **Do not place that URL on your CV until it actually opens.**

## Google Sites — create the research portfolio URL

1. Sign into https://sites.google.com with the account you want employers to see. Choose a blank site and name it **Dorcas Oluwafunmitoju | Computational Research Portfolio**.
2. Copy the human-readable paragraphs in [`GOOGLE_SITES_COPY.md`](GOOGLE_SITES_COPY.md) into the page. Add the four `.png` files from `figures/` beside the matching project sections.
3. Add buttons linking to your actual GitHub repository and GitHub Pages website. You can also link or embed `docs/reports/Research_Portfolio_Report.pdf` after placing the PDF somewhere publicly accessible, such as a Google Drive file with an appropriate sharing setting.
4. Click **Publish** in Google Sites, select your desired address, and configure visibility appropriately. Open the published URL in a signed-out browser to verify outside visitors can access it.
5. The **Google Sites URL** is the full address shown in the browser after publishing. Copy that URL into your CV's **Research portfolio** field. Use the GitHub repo URL in its **GitHub** field.

## Before making CV claims

This package contains new independently reproducible, AI-assisted demonstration work. Some specific figures in the old target CV were explicitly *illustrative*, and its original template described academic roles as fictional. **Do not claim** that the sample universities, research appointments, dates, thesis or old numerical metrics became authentic simply because the labels were deleted. Verify qualifications and past work with your own records. The values in this package's generated report are measured under the indicated synthetic configuration and may replace illustrative *project* figures if you confirm that you understand and have completed the studies.

## What URLs mean

A URL is a web address, such as `https://github.com/YOUR-USERNAME/computational-research-portfolio`. Place only URLs that actually exist and that a recruiter can open without requesting a password.

# Scientific background and further reading

The implementations were written for this portfolio and the following works are background reading, not claims of implementing every method from those sources.

1. Givoli, D. (2021). *A tutorial on the adjoint method for inverse problems*. Computer Methods in Applied Mechanics and Engineering, 380, 113810. https://doi.org/10.1016/j.cma.2021.113810
2. Rubino, G. (2021). *Transient Analysis of Markovian Queueing Systems: A Survey with Focus on Closed-forms and Uniformization*. https://doi.org/10.1002/9781119755234.ch8
3. Uniformization derivation and transition matrix discussion: https://en.wikipedia.org/wiki/Uniformization_(probability_theory) (introductory reference; original literature is preferable for formal use)
4. Source-code API documentation: SciPy sparse linear algebra: https://docs.scipy.org/doc/scipy/reference/sparse.linalg.html; SciPy optimization: https://docs.scipy.org/doc/scipy/reference/optimize.html; SciPy matrix exponential: https://docs.scipy.org/doc/scipy/reference/generated/scipy.linalg.expm.html

The latent-variable correlated-test score in Study 3 follows directly from conditional independence and the law of total probability; no outside dataset or benchmark is used.
